LINE KICK ALL BOT

具有迅速破壞 LINE 群組能力的 BOT

# *要求* 

node >= v8.x.x

可通過 `node -v` 指令檢查
[升級nodejs](https://nodejs.org/en/)

# *警告*

此程序可能導致帳號作廢
使用前請三思帳號是很珍貴的
可用在用需解散之群組
如不當使用後果自負

# 原生

前生 => [Line Alphat JS](https://github.com/alfathdirk/LineAlphatJS)
作者 => [@alfathdirk](https://instagram.com/alfathdirk)

# 修改內容

- 移除管理員才可破壞
- 修正舊版一次全部取消改為一個個取消
- 修正全踢過度 getgroup 問題

# *使用方法*

## *第一步*：環境架設

### Android 手機

1. 下載並安裝[Termux](https://play.google.com/store/apps/details?id=com.termux&hl=zh_TW)

2. 下載並安裝[Termux:API](https://play.google.com/store/apps/details?id=com.termux.api&hl=zh_TW)

3. 安裝腳本

- `apt install termux-api`
- `pkg install git`

### 電腦

1. 下載並安裝[Node.js](https://nodejs.org/en/)
2. 下載並安裝[git](https://git-scm.com/downloads)

## *第二步*：檔案下載(電腦或手機都一樣)

- `git clone git@github.com:Phyllis62418/LINEKICKALL.git`
- `cd LINEKICKALL`

## *第三步*：程式運行(電腦或手機都一樣)

- `npm install`
- `npm start`

## *第四部*：登入帳號

- 將 line://au/q/.... 網址複製於手機並登入
- 在想破壞之群組輸入 kickAll 即可全踢除(注意大小寫)

# 程式簡易修改

為了避免防翻及過濾字串，於目錄下

`\src\main.js`

第 127 行 可以變更破壞指令